package br.pedroochial;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class AppTest {

    @Test
    void testApp() {
        assertTrue(true, "Teste básico de funcionamento.");
    }
}
